package storage

import (
	"github.com/jmoiron/sqlx"
	_ "github.com/lib/pq"
)

type DBConfig struct {
	DBUrl string
}
type Storage struct {
	DB     *sqlx.DB
	config DBConfig
}

func New(cfg DBConfig) (*sqlx.DB, error) {
	/*op := "storage.postgres.New"
	db, err := sqlx.Open("postgres", cfg.DBUrl)

	if err != nil {
		return nil, fmt.Errorf("%s: %v", op, err)
	}
	err = db.Ping()
	if err != nil {
		return nil, fmt.Errorf("%s: %v", op, err)
	}
	defer func(db *sqlx.DB) {
		err := db.Close()
		if err != nil {
			panic(err)
		}
	}(db)*/
	return nil, nil
}
