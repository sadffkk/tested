package models

type App struct {
	ID     int
	Name   string
	Secret string // TODO: think about moving this out
}
